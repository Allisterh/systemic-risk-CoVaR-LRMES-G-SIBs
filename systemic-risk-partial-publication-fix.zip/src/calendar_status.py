"""Primary-equity session calendar. Missing quotes alone never prove a holiday.

Exchange calendars are versioned software estimates, not a live exchange feed.
Index outages/halts are not inferred from the equity calendar.
"""
from datetime import datetime, timezone, timedelta
from functools import lru_cache
import importlib.metadata
import math
import pandas as pd
from src.universe import BANKS
from src.config import cfg


def calendar_name(bank):
    suffixes = {'.HK':'XHKG', '.L':'XLON', '.PA':'XPAR', '.DE':'XETR',
                '.SW':'XSWX', '.AS':'XAMS', '.MC':'XMAD', '.TO':'XTSE', '.T':'XTKS'}
    return next((name for suffix,name in suffixes.items() if bank.yf_ticker.endswith(suffix)),
                'XNYS' if bank.region == 'US' else None)


@lru_cache(maxsize=100)
def _calendar(name, year):
    import exchange_calendars as xc
    return xc.get_calendar(name, start=f'{year-2}-01-01', end=f'{year+1}-12-31')


def session_status(bank, requested_date, observed_date=None, *, now=None):
    now = pd.Timestamp(now or datetime.now(timezone.utc))
    if now.tzinfo is None: now = now.tz_localize('UTC')
    result = {'requested_date':requested_date, 'observation_date':observed_date,
              'calendar':calendar_name(bank), 'calendar_scope':'primary_equity',
              'expected_session_date':None, 'status':'unknown_calendar'}
    if not bank.supported:
        return {**result, 'status':'unsupported', 'reason':bank.exclusion_reason}
    try:
        day = pd.Timestamp(requested_date)
        cal = _calendar(result['calendar'], day.year)
        result['calendar_version'] = importlib.metadata.version('exchange-calendars')
        sessions = cal.sessions_in_range(day-pd.Timedelta(days=40), day)
        due = [s for s in sessions if cal.session_close(s)+pd.Timedelta(minutes=cfg.market_close_grace_minutes) <= now]
        expected = due[-1].strftime('%Y-%m-%d') if due else None
        is_session = bool(cal.is_session(day))
        result.update(expected_session_date=expected, is_session=is_session)
        if observed_date == requested_date:
            status = 'observed'
        elif not is_session:
            status = 'market_closed'
        elif day.strftime('%Y-%m-%d') != expected:
            status = 'not_yet_due'
        else:
            status = 'missing_data'
        result['status'] = status
        result['up_to_date'] = bool(observed_date and expected and observed_date >= expected)
        return result
    except Exception as exc:
        return {**result, 'reason':f'Calendar unavailable: {type(exc).__name__}'}


def publication_report(payload, observations, target_date, *, now=None):
    """Freshness uses the wall clock; closed markets still need their last due result."""
    if cfg.publication_mode not in {'research', 'historical', 'production'}:
        raise ValueError('Unknown PUBLICATION_MODE')
    now = now or datetime.now(timezone.utc)
    current_day = now.date().isoformat()
    states = {}
    for bank in BANKS:
        observation = observations.get(bank.id, {})
        state = session_status(bank, current_day, observation.get('srisk_date'), now=now)
        if observation.get('failure'):
            state['input_failure'] = observation['failure']
            if state['status'] == 'missing_data': state['status'] = 'fetch_or_calculation_failed'
        states[bank.id] = state
    if cfg.publication_basis not in {'srisk','market_metrics'}:
        raise ValueError('PUBLICATION_BASIS must be srisk or market_metrics')
    metric_status = {}
    for metric in ('mes','lrmes','covar','delta_covar','srisk_usd_bn'):
        metric_status[metric] = {bank.id:session_status(bank,current_day,
            observations.get(bank.id,{}).get('metric_dates',{}).get(metric),now=now) for bank in BANKS if bank.supported}
    eligible = [b.id for b in BANKS if b.supported]
    ready = [bid for bid in eligible if states[bid].get('up_to_date')]
    reasons = []
    warnings = []
    if not 0 < cfg.min_publication_coverage <= 1:
        raise ValueError('MIN_PUBLICATION_COVERAGE must be in (0,1]')
    if cfg.publication_basis == 'market_metrics':
        ready = [bid for bid in eligible if all(metric_status[m][bid].get('up_to_date') for m in ('mes','lrmes','covar','delta_covar'))]
    elif not payload.get('coverage', {}).get('srisk_count'): reasons.append('NO_SRISK')
    # Coverage is advisory; valid partial/stale observations remain publishable.
    ratio = len(ready)/len(eligible) if eligible else 0.0
    if ratio < cfg.min_publication_coverage:
        warnings.append('INSUFFICIENT_FRESH_ELIGIBLE_COVERAGE')
    metrics = ('mes','lrmes','covar','delta_covar') if cfg.publication_basis == 'market_metrics' else ('srisk_usd_bn',)
    valid_ids = sorted({bank.get('bank_id') for bank in payload.get('banks', [])
        if bank.get('bank_id') in eligible and any(
            isinstance(bank.get(m), (int, float)) and not isinstance(bank.get(m), bool)
            and math.isfinite(bank[m]) for m in metrics)})
    if not valid_ids:
        reasons.append('NO_VALID_METRICS')
    for by_bank in metric_status.values():
        for state in by_bank.values():
            state['as_of'] = state['observation_date']
            state['freshness'] = ('unavailable' if not state['observation_date'] else
                                  'fresh' if state.get('up_to_date') else 'stale')
    if payload.get('dataset_kind') in ('historical_reconstruction','synthetic_test'): reasons.append('NON_PRODUCTION_DATASET')
    if target_date > current_day: reasons.append('FUTURE_TARGET')
    if any(a.get('severity') == 'error' for a in payload.get('quality',{}).get('alerts',[])):
        reasons.append('QUALITY_ERROR')
    return {'mode':cfg.publication_mode, 'target_date':target_date,
            'evaluated_at':now.isoformat(), 'basis':cfg.publication_basis, 'fresh_eligible_count':len(ready),
            'metric_status':metric_status,
            'fresh_count_by_metric':{m:sum(bool(s.get('up_to_date')) for s in by_bank.values()) for m,by_bank in metric_status.items()},
            'eligible_count':len(eligible), 'minimum_ratio':cfg.min_publication_coverage,
            'bank_status':states, 'reasons':reasons, 'warnings':warnings,
            'coverage_policy':'advisory', 'fresh_coverage_ratio':ratio,
            'data_status':'complete' if len(ready)==len(eligible) and eligible else 'partial',
            'valid_snapshot_ids':valid_ids,
            'not_fresh_ids':sorted(set(eligible)-set(ready)),
            'decision':'rejected' if reasons and cfg.publication_mode=='production' else 'accepted'}
